StrengthSMP v1.3.0 - Paper 1.21.11 / Java 21

Features:
- Enchanted Sunflower of Strength: right-click to gain +1 Strength.
- Strength is persistent and may go negative; each death removes 1, including 0 -> -1.
- Each Strength level adds 5% damage; negative damage reduction is capped at 90%.
- At Strength -25 or lower after death, player is permanently banned by name.
- Revival mechanic: an enchanted sunflower renamed in an anvil to the banned player's exact Minecraft username is consumed, unbans them, and sets their saved Strength to -24.
- Admin commands: /strength, /strength give <player> <amount>, /strength set <player> <level>.

Build: Java 21 + Maven, run `mvn clean package` in this project directory.
The output JAR is in target/. Build has not been verified in this environment; run the GitHub Actions workflow and confirm success before installing.
