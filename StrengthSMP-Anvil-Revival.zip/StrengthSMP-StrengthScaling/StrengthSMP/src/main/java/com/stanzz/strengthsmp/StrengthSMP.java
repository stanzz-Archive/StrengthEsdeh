package com.stanzz.strengthsmp;

import org.bukkit.BanList;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.Locale;

public final class StrengthSMP extends JavaPlugin implements Listener {
    private NamespacedKey strengthItemKey;
    private static final String PREFIX = ChatColor.GOLD + "[StrengthSMP] " + ChatColor.RESET;
    private static final int MAX_LEVEL = 100000;
    private static final int MIN_LEVEL = -100000;

    @Override
    public void onEnable() {
        strengthItemKey = new NamespacedKey(this, "strength_sunflower");
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("StrengthSMP enabled (negative levels and per-level damage scaling enabled).");
    }

    private String path(UUID id) { return "players." + id; }

    // Do not clamp this to zero: negative Strength is intentional.
    public int getStrength(Player p) {
        return Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, getConfig().getInt(path(p.getUniqueId()), 0)));
    }

    private void setStrength(Player p, int value) {
        setStrength(p.getUniqueId(), value);
    }

    private void setStrength(UUID playerId, int value) {
        int safe = Math.max(MIN_LEVEL, Math.min(MAX_LEVEL, value));
        getConfig().set(path(playerId), safe);
        saveConfig();
    }

    private ItemStack makeSunflower(int amount) {
        ItemStack item = new ItemStack(Material.SUNFLOWER, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.YELLOW + "✦ Sunflower of Strength ✦");
            meta.setLore(List.of(ChatColor.GRAY + "Right-click to gain +1 Strength", ChatColor.DARK_GRAY + "Stanzz Studio"));
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.setUnbreakable(true);
            meta.getPersistentDataContainer().set(strengthItemKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean isStrengthSunflower(ItemStack item) {
        if (item == null || item.getType() != Material.SUNFLOWER || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(strengthItemKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (!isStrengthSunflower(item)) return;
        event.setCancelled(true);
        Player p = event.getPlayer();
        int old = getStrength(p);
        if (old >= MAX_LEVEL) {
            p.sendMessage(PREFIX + ChatColor.RED + "Strength sudah mencapai batas maksimum.");
            return;
        }
        if (item.getAmount() <= 1) p.getInventory().setItemInMainHand(null);
        else item.setAmount(item.getAmount() - 1);
        setStrength(p, old + 1);
        p.sendMessage(PREFIX + ChatColor.GREEN + "Strength kamu sekarang: " + ChatColor.YELLOW + (old + 1));
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isStrengthSunflower(event.getItemInHand())) event.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        int oldLevel = getStrength(victim);
        // Always lose one point, including 0 -> -1, -1 -> -2, etc.
        int newLevel = oldLevel - 1;
        setStrength(victim, newLevel);
        event.getDrops().add(makeSunflower(1));
        victim.sendMessage(PREFIX + ChatColor.RED + "Kamu kehilangan 1 Strength. Sisa: " + newLevel);
        Player killer = victim.getKiller();
        if (killer != null) {
            killer.sendMessage(PREFIX + ChatColor.GOLD + victim.getName() + " menjatuhkan 1 Sunflower of Strength!");
        }

        // Permanently ban a player when death reduces their Strength to the configured threshold.
        if (getConfig().getBoolean("ban.enabled", true)
                && newLevel <= getConfig().getInt("ban.threshold", -25)) {
            String reason = getConfig().getString("ban.reason", "Strength mencapai -25.");
            getServer().getBanList(BanList.Type.NAME).addBan(victim.getName(), reason, (Date) null, "StrengthSMP");
            String reviveKey = victim.getName().toLowerCase(Locale.ROOT);
            getConfig().set("revival.pending." + reviveKey, victim.getUniqueId().toString());
            saveConfig();
            victim.kickPlayer(ChatColor.RED + "Kamu diban permanen karena Strength mencapai " + newLevel
                    + ". Pemain lain bisa menghidupkanmu dengan menamai Sunflower of Strength menjadi " + victim.getName() + ".");
            getLogger().info("Banned " + victim.getName() + " at Strength " + newLevel
                    + ". Rename an enchanted sunflower to their exact username to revive them.");
        }
    }

    @EventHandler
    public void onAnvilRenameRevive(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory() instanceof AnvilInventory anvil)) return;
        if (event.getRawSlot() != 2) return; // Result slot only.
        ItemStack result = event.getCurrentItem();
        if (result == null || result.getType() != Material.SUNFLOWER || !result.hasItemMeta()) return;
        ItemMeta meta = result.getItemMeta();
        if (meta == null || !meta.hasDisplayName() || !meta.hasEnchants()) return;

        String enteredName = ChatColor.stripColor(meta.getDisplayName()).trim();
        if (enteredName.isEmpty()) return;
        String reviveKey = enteredName.toLowerCase(Locale.ROOT);
        String uuidText = getConfig().getString("revival.pending." + reviveKey);
        if (uuidText == null) return; // This username is not awaiting revival.

        UUID playerId;
        try {
            playerId = UUID.fromString(uuidText);
        } catch (IllegalArgumentException ex) {
            getLogger().warning("Invalid pending revival UUID for " + enteredName + ".");
            return;
        }

        // Consume the renamed sunflower rather than allowing the output to be duplicated.
        event.setCancelled(true);
        anvil.setItem(0, null);
        anvil.setItem(1, null);
        anvil.setItem(2, null);
        getServer().getBanList(BanList.Type.NAME).pardon(enteredName);
        setStrength(playerId, -24);
        getConfig().set("revival.pending." + reviveKey, null);
        saveConfig();

        Player reviver = event.getWhoClicked() instanceof Player p ? p : null;
        if (reviver != null) {
            reviver.sendMessage(PREFIX + ChatColor.GREEN + "Berhasil menghidupkan " + enteredName
                    + "! Ban dibuka dan Strength mereka menjadi -24. Sunflower telah dikonsumsi.");
        }
        getLogger().info(enteredName + " was unbanned by the anvil sunflower revival mechanic; Strength set to -24.");
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        int level = getStrength(attacker);
        // Every positive level increases damage by the configured percentage.
        // Negative levels reduce damage, but never reduce it below the configured floor.
        double perLevel = getConfig().getDouble("damage.per-strength-level", 0.05);
        int maxPositive = Math.max(1, getConfig().getInt("damage.max-positive-level", 1000));
        double minMultiplier = Math.max(0.01, Math.min(1.0,
                1.0 - getConfig().getDouble("damage.max-negative-reduction", 0.90)));
        int appliedLevel = Math.max(-100000, Math.min(maxPositive, level));
        double multiplier = 1.0 + (appliedLevel * perLevel);
        multiplier = Math.max(minMultiplier, multiplier);
        event.setDamage(event.getDamage() * multiplier);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Use /strength give <player> <amount> or /strength set <player> <level>.");
                return true;
            }
            p.sendMessage(PREFIX + "Strength kamu: " + ChatColor.YELLOW + getStrength(p));
            double perLevel = getConfig().getDouble("damage.per-strength-level", 0.05) * 100.0;
            p.sendMessage(ChatColor.GRAY + "Setiap +1 Strength: +" + String.format(java.util.Locale.US, "%.0f", perLevel)
                    + "% damage; level negatif mengurangi damage.");
            return true;
        }
        if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Kamu tidak punya izin.");
            return true;
        }
        if (args.length == 3 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("set"))) {
            Player target = getServer().getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Pemain harus sedang online.");
                return true;
            }
            int amount;
            try { amount = Integer.parseInt(args[2]); }
            catch (NumberFormatException ex) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Jumlah harus angka.");
                return true;
            }
            if (args[0].equalsIgnoreCase("give")) {
                if (amount < 1 || amount > 64) {
                    sender.sendMessage(PREFIX + "Jumlah item harus 1-64.");
                    return true;
                }
                getServer().getScheduler().runTask(this, () -> {
                    var leftovers = target.getInventory().addItem(makeSunflower(amount));
                    leftovers.values().forEach(drop -> target.getWorld().dropItemNaturally(target.getLocation(), drop));
                });
                sender.sendMessage(PREFIX + "Memberikan " + amount + " Sunflower of Strength ke " + target.getName() + ".");
            } else {
                setStrength(target, amount);
                target.sendMessage(PREFIX + "Strength kamu diatur menjadi " + getStrength(target) + ".");
                sender.sendMessage(PREFIX + "Strength " + target.getName() + " = " + getStrength(target));
            }
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "/strength" + ChatColor.GRAY + " - cek levelmu");
        sender.sendMessage(ChatColor.YELLOW + "/strength give <player> <1-64>" + ChatColor.GRAY + " - beri sunflower");
        sender.sendMessage(ChatColor.YELLOW + "/strength set <player> <level>" + ChatColor.GRAY + " - atur level, termasuk negatif");
        return true;
    }
}
